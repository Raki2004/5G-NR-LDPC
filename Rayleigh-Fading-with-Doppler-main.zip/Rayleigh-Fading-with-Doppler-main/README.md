# Rayleigh-Fading-with-Doppler
- Generate fading envolop using sum of sinusoids methods
- Compute delays and avarage power of each tap given power delay profile
- Generate power delay profile for exponetial decay channel
- Generate channel coefficients(nTaps X nSamples) given power delay profile, maximum doppershift, numer of samples
for  the case of N_t X N_r MIMO, the channel coefficients can be generated independently for N_t X N_r times to obtain a 4-D channel coefficients like MATLAB 5G tool box does
